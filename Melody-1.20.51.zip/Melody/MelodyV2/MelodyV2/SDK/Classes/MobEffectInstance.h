#pragma once

class MobEffectInstance;