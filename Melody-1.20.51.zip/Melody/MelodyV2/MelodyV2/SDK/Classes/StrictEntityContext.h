#pragma once



class StrictEntityContext
{

};