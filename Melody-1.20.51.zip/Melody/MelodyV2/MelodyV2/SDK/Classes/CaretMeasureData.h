#pragma once

class CaretMeasureData {
};